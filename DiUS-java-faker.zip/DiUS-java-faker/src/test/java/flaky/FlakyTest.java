package flaky;
import edu.utexas.ece.flakytracker.agent.FlakyTaintLabel;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import edu.columbia.cs.psl.phosphor.runtime.MultiTainter;
import edu.columbia.cs.psl.phosphor.runtime.Taint;

import java.util.Random;
// import flaky.FlakyUtil;


@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class FlakyTest {

    public static boolean debug = false;

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TestGroup100Case0.test021");
        java.util.Random random0 = null;
        com.github.javafaker.Faker faker1 = new com.github.javafaker.Faker(random0);
        com.github.javafaker.Photography photography2 = faker1.photography();
        java.lang.String str3 = photography2.brand();
        Random e = new Random();
        int bb = 0;
//        e = MultiTainter.taintedReference(e, new FlakyTaintLabel(3, "SHARED_RANDOM", "edu/utexas/ece/flakytracker/FlakyTrackerTest", 36, 7));
//        e = MultiTainter.taintedReference(e, new edu.utexas.ece.flakytracker.agent.FlakyTaintLabel(1, "java/util/Random.<init>", "edu/utexas/ece/flakytracker/FlakyTrackerTest", 36, 6));
//        bb = MultiTainter.taintedInt(bb,0);
//        bb = MultiTainter.taintedInt(bb,1);
//        FlakyUtil.checkTainted(bb,"a");
        // FlakyUtil.checkTainted(str3);
//        System.out.println(MultiTainter.getTaint(str3));
         org.junit.Assert.assertNotNull(photography2);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "Tokina" + "'", str3, "Tokina"); //flaky
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TestGroup100Case0.test045");
        java.util.Random random0 = null;
        com.github.javafaker.Faker faker1 = new com.github.javafaker.Faker(random0);
        com.github.javafaker.Photography photography2 = faker1.photography();
        com.github.javafaker.IdNumber idNumber3 = faker1.idNumber();
        com.github.javafaker.App app4 = faker1.app();
        com.github.javafaker.Hacker hacker5 = faker1.hacker();
        java.lang.String str7 = faker1.letterify("Mr Peanutbutter");
        org.junit.Assert.assertNotNull(photography2);
        org.junit.Assert.assertNotNull(idNumber3);
        org.junit.Assert.assertNotNull(app4);
        org.junit.Assert.assertNotNull(hacker5);
        // System.out.println(MultiTainter.getTaint(str7));
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "Mr Peanutbutter" + "'", str7, "Mr Peanutbutter");
    }


}

