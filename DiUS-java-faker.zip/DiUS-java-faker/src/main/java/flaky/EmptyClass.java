package flaky;

public class EmptyClass {
    static int a;
}
