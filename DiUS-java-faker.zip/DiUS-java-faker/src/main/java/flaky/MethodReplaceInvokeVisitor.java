package flaky;

public class MethodReplaceInvokeVisitor {
}
