package flaky;
import edu.columbia.cs.psl.phosphor.runtime.MultiTainter;
import edu.columbia.cs.psl.phosphor.runtime.Taint;
import edu.columbia.cs.psl.phosphor.struct.TaintedWithObjTag;
import org.apache.commons.io.FileUtils;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.util.ASMifier;
import org.objectweb.asm.util.Printer;
import org.objectweb.asm.util.Textifier;
import org.objectweb.asm.util.TraceClassVisitor;
import org.objectweb.asm.*;

import static org.objectweb.asm.Opcodes.*;


import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.Arrays;

public class FlakyUtil {
    public static <T> void checkTainted(T a, String testName) {
        System.out.println("come in");
        Taint taint = MultiTainter.getTaint(a);
        for (Object label : taint.getLabels()) {
            if (label instanceof FlakyTaintLabel) {
                FlakyTaintLabel taintLabel = (FlakyTaintLabel) label;
                System.out.println(taintLabel);
            }
        }
        System.out.println(taint);
    }
    int test = 0;

    public static void main(String[] args) throws IOException {
        EmptyClass.a = 1;
        String className = "com.github.javafaker.service.RandomService";
//        className = "org.objectweb.asm.ClassReader";
//        FlakyDemo.noninitial = 1;
        System.out.println(FlakyDemo.noninitial);
        int parsingOptions = ClassReader.SKIP_FRAMES | ClassReader.SKIP_DEBUG;
        boolean asmCode = true;
        System.out.println(Arrays.toString(className.split("\\$")));

        // (2) 打印结果
        Printer printer = asmCode ? new ASMifier() : new Textifier();
        PrintWriter printWriter = new PrintWriter(System.out, true);
        TraceClassVisitor traceClassVisitor = new TraceClassVisitor(null, printer, printWriter);
//        new ClassReader(className).accept(traceClassVisitor, parsingOptions);
        ClassReader classReader = new ClassReader(className);

        ClassWriter classWriter = new ClassWriter(classReader,parsingOptions);
//        new Class(classWriter);



        classReader.accept(traceClassVisitor,0);
//        System.out.println(Arrays.toString(classWriter.toByteArray()));
        FileUtils.writeByteArrayToFile(new File("target/classes/flaky/LastCode.class"),classReader.b);

    }






}