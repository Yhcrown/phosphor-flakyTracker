package flaky;
import edu.columbia.cs.psl.phosphor.runtime.MultiTainter;

import java.util.Date;
import java.util.Random;

class TestFather{
    static int cc ;
}
public class FlakyDemo extends TestFather{



    public static boolean debug = false;

    static Object a = new Object();
    static int butterfly = 1 ;

    static int taintb = 1;

    int publicint = 0;

    static int pubint2 = 0;

    static final int noninitial = 1;

    Random randommm = new Random();
    final int pub3 = 1145142;

    static Integer c = 1;

    static double bb = 1.2;

    static Boolean ddd;

    Random aran = new Random();

    static final Random bran = new Random();

    static Random cran;



    static {



        int sha = 6;
        int bi ;
        System.out.println(butterfly);
        butterfly = 2;
        System.out.println(butterfly);
//        MultiTainter.taintedInt(taintb,1);
    }
    Random r = new Random();
//    public static void dummyAssert(String s1,String s2,String s3){
//        if (!s2.equals(s3))
//            System.out.println(s1);
//    }
    public void test021() throws Throwable {

        pubint2 = 3;
        pubint2 = MultiTainter.taintedInt(pubint2,1);
        FlakyUtil.checkTainted(pubint2,"");
        System.out.println("woshishabi");
        MultiTainter.taintedInt(noninitial,1);
//        pubint2 = 3;
        int a = new FlakyUtil().test;
        new FlakyUtil().test = 2;
        MultiTainter.taintedInt(butterfly,"a");
        new hah().haha = 1;
        cc = 2;
        if (debug)
            System.out.format("%n%s%n", "TestGroup100Case0.test021");
        java.util.Random random0 = null;
        com.github.javafaker.Faker faker1 = new com.github.javafaker.Faker(random0);
        com.github.javafaker.Photography photography2 = faker1.photography();
        java.lang.String str3 = photography2.brand();
        FlakyUtil.checkTainted(str3,"test021");
//        FlakyUtil.checkTainted("Tokina");
//        dummyAssert("'" + str3 + "' != '" + "Tokina" + "'", str3, "Tokina"); //flaky
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "Tokina" + "'", str3, "Tokina"); //flaky
    }
    public static class hah{
        int haha= 0 ;

        public class innerhaha{
            int ihaha = 0;
        }

    }

    public void test021_o() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TestGroup100Case0.test021");
        publicint = 1;
        FlakyUtil.checkTainted(publicint,"ss");
        java.util.Random random0 = null;
        com.github.javafaker.Faker faker1 = new com.github.javafaker.Faker(random0);
        com.github.javafaker.Photography photography2 = faker1.photography();
        java.lang.String str3 = photography2.brand();
        Long.valueOf(1);
        org.junit.Assert.assertEquals("aa",1,-1);
//        dummyAssert("'" + str3 + "' != '" + "Tokina" + "'", str3, "Tokina"); //flaky
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "Tokina" + "'", str3, "Tokina"); //flaky
    }


    public int testa(){
        int x = r.nextInt();
        Random random = new Random();
        random.nextInt();
        random.nextFloat();
        random.nextLong();
        random.nextBoolean();
        random.nextGaussian();
        Date date = new Date();

        int y = x +1;
        return y;
    }

    public int testb(){
        int x = r.nextInt();
        x = MultiTainter.taintedInt(x,new FlakyTaintLabel(FlakyTaintLabel.RANDOM,"Random.nextInt()",12,114514));
        int y = x +1;
        return y;
    }

    public int testb_or(){
        int x = r.nextInt();
        int y = x +1;
        return y;
    }
}

