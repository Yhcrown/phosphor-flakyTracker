package com.github.javafaker;

public enum CreditCardType {
    VISA,
    MASTERCARD,
    DISCOVER,
    AMERICAN_EXPRESS,
    DINERS_CLUB,
    JCB,
    SWITCH,
    SOLO,
    DANKORT,
    FORBRUGSFORENINGEN,
    LASER
}
